import React from 'react';
import UserCard from './UserCard';


class CourseList extends React.Component {

  state = {
    courses: [
      {
        title: "Physics",
        id: 1,
        tutor: "Johnson Kengne",
        registered: 15,
        courseClass: "upperSixth",
        image: "assets/img/courses/phy.jpeg",
        period: "1 Year",
        detail: "this an advance level Physics course"
      },
      {
        title: "Chemistry",
        id: 2,
        tutor: "Daniel Tchangang",
        registered: 25,
        courseClass: "lowerSixth",
        image: "assets/img/courses/chem.jpeg",
        period: "2 Year",
        detail: "this an advance level Chemistry course"
      },
      {
        title: "Biology",
        id: 3,
        tutor: "Boris Tchangang",
        registered: 30,
        courseClass: "formFive",
        image: "assets/img/courses/bio.jpeg",
        period: "1 Year",
        detail: "this an advance level Biology course"
      },
      {
        title: "O Level Maths",
        id: 4,
        tutor: "Charles Komeh",
        registered: 5,
        courseClass: "form3",
        image: "assets/img/courses/maths.jpeg",
        period: "3 Year",
        detail: "this an ordinary level maths course"
      },
      {
        title: "Algorithms",
        id: 5,
        tutor: "Eric Signer",
        registered: 3,
        courseClass: "upperSixth",
        image: "assets/img/courses/algo.png",
        period: "1 Year",
        detail: "this an Algorithm course For any one with  the will to learn it"
      }
    ]
  };

  // handles event from each list items
  clickDisplay = (course, e) => {
    this.props.display(course);
  }

  render() {
    return (
      <div className="col-md-3 course-list">
        <h3></h3>
        <UserCard />
        <p className={"header"} >Courses List</p>
        <div className="list-group">

          {
            this.state.courses.map((course) => {
              return <button key={course.id} onClick={(e) => this.clickDisplay(course, e)} className="sidelinks list-group-item list-group-item-action">{course.title}</button>
            })
          }
        </div>
        <p className={"header"} >Student Statistics</p>
      </div>
    );
  }
}

export default CourseList;

import React, { Component } from 'react';


class UserCard extends Component {
    state = {}
    render() {
        return (
            <div className="user-panel">
                <div className="pull-left image">
                    <img src="assets/img/bg/bg1.jpg" className="img-circle" alt="User Image" />
                </div>
                <div className="pull-left info">
                    <p>Johnson Kengne</p>
                    <a><i className="fa fa-circle text-success"></i> UpperSixth</a>
                </div>
            </div>

        );
    }
}

export default UserCard;
import React, { Component } from 'react';

class CourseDetail extends Component {

    render() {
        return (
            <div className="col-md-9 course-detail">
                <h3>Courses Detail</h3>
                <div className={" main-info col-md-5 col-md-offset-1"}>
                    <img className="course-img" src={this.props.singleCourse.image} width={100 + '%'} height={200 + 'px'} alt="Physics Course" />
                    <p>
                        <span>Course Title:</span>
                        <span className="right-val">{this.props.singleCourse.title}</span>
                    </p>
                    <p>
                        <span>Course Tutor:</span>
                        <span className="right-val">{this.props.singleCourse.tutor}</span>
                    </p>
                    <p>
                        <span>Number Registered:</span>
                        <span className="right-val">{this.props.singleCourse.registered}</span>
                    </p>
                    <p>
                        <span>Course class:</span>
                        <span className="right-val">{this.props.singleCourse.courseClass}</span>
                    </p>
                    <p>
                        <span>Course Period:</span>
                        <span className="right-val">{this.props.singleCourse.period}</span>
                    </p>
                    <button type="button" className="btn btn-success btn-lg full" name="button">Register Course</button>
                </div>
                <div className={" main-info col-md-5"}>
                    <h4>Course details</h4>
                    <p>
                        {this.props.singleCourse.detail}
                    </p>
                </div>
            </div>
        );
    }
}

export default CourseDetail;
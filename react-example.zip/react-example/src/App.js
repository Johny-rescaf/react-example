import React, { Component } from 'react';
import CourseList from './components/CourseList';
import CourseDetail from './components/CourseDetail';

class App extends Component {

  state = {
    course: {
      title: "",
      id: 0,
      tutor: "",
      registered: 0,
      courseClass: "",
      image: "assets/img/courses/default.png",
      period: "",
      detail: ""
    }
  }

  displayDetail = (courseObj) => {
    this.setState({ course: courseObj });
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-10 col-md-offset-1 wrapper">
            <div className="row">
              <CourseList display={this.displayDetail} />
              <CourseDetail singleCourse={this.state.course} />
            </div>
          </div>
        </div>
      </div >
    );
  }
}

export default App;
